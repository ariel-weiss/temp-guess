
export const INIT_ANSWERS = 'INIT_ANSWERS';
export const ADD_GUESS = 'ADD_GUESS';